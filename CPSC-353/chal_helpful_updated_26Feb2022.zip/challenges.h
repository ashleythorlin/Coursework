#ifndef __CHALLENGES_H__
#define __CHALLENGES_H__

int challenge_1();
int challenge_2();
int challenge_3();
int challenge_4();
int challenge_5();

#endif 