#ifndef __CHALLENGE_2_H__
#define __CHALLENGE_2_H__

int challenge_2();

#endif 