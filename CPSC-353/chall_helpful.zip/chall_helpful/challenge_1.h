#ifndef __CHALLENGE_1_H__
#define __CHALLENGE_1_H__

int challenge_1();

#endif 