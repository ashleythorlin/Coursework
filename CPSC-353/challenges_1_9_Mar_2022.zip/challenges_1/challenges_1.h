#ifndef __CHALLENGES_H__
#define __CHALLENGES_H__

int challenge_1_1();
int challenge_1_2();
int challenge_1_3();
int challenge_1_4();
int challenge_1_5();

int challenge_1_6();
int challenge_1_7();
int challenge_1_8();


#endif 