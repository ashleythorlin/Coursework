#ifndef Utils_h
#define Utils_h

#include <string>
#include <iostream>
#include <cstdlib>
#include <map>
#include <cmath>
#include <cstring>
#include <string.h>
#include <fstream>


#include <ctype.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>

//CHALLENGE 1

char decimalValue(char hex) { //converts 'A' to 10 (comes after 0-9)
    if (!isxdigit(hex)) {
        throw new std::invalid_argument("Not a valid hex char.\n");
    }

    char value = 0;
    hex = toupper(hex);
    if ('A' <= hex && hex <= 'F') {
        value = hex - 'A' + 10;
    } else {
        value = hex - '0';
    }

    return value; 
}

char toBase64(char c) { 
    if (c < 26) { return c + 65; 
    } else if (c < 52) { return c + 71; 
    } else if (c <= 61) { return c - 4; 
    } else if (c == 62) { return 43; 
    } else { return 47; }
}

void decodeHex(const char* source, char* dest, int n) {
    n--;
    for (int i = 0, j = 0; i < n; i+=2, ++j){     //test
        dest[j] = decimalValue(source[i]) << 4 | decimalValue(source[i + 1]);
    }
    std::cout << "Source Data: ";
    for (int i = 0; i < n; ++i){
        std::cout << source[i];
        if (i % 6 == 5){
            std::cout << " ";
        }
    }
    std::cout << "\n";
}

void base64(const char* source, char* dest) {       //
    unsigned long combined = (source[0] << 16) | (source[1] << 8) | source[2];
    unsigned mask = 63;  //111111

    for(int i = 18, j = 0; i >= 0; i-= 6, ++j){
        dest[j] = toBase64((combined >> i) & mask);
    }
}   

void convertToBase64(const char* source, char* dest, int n) {    //converts to base64
    for (int i = 0, j = 0; i < n; i += 3, j += 4) {
        base64(source + i, dest + j);
    }
}

//CHALLENGE 2
void blockXor(const char* source1, const char* source2, char* dest, int n){     //xor's the string
    for (int i = 0; i < n; i++){
        dest[i] = (char)((unsigned)source1[i] ^ (unsigned)source2[i]);
    }
}

char hexChar(char value){   //converts decimal number to hex character
    if (value > 15){
        throw new std::invalid_argument("Decimal is not a valid hex value.");
    }
    if (value < 10) {
        return '0' + value;
    } else {
        return 'A' + value - 10;
    }
}

//CHALLENGE 3
static std::map<char, double> freq, english_freq = { {'a', 0.0766}, {'b', 0.0237}, {'c', 0.0264}, {'d', 0.0283}, {'e', 0.0719}, 
                    {'f', 0.0129}, {'g', 0.0190}, {'h', 0.0247}, {'i', 0.0477}, {'j', 0.0087}, 
                    {'k', 0.0201}, {'l', 0.0385}, {'m', 0.0308}, {'n', 0.0464}, {'o', 0.0524}, 
                    {'p', 0.0253}, {'q', 0.0036}, {'r', 0.0505}, {'s', 0.0472}, {'t', 0.0395}, 
                    {'u', 0.0214}, {'v', 0.0086}, {'w', 0.0128}, {'x', 0.0057}, {'y', 0.0152},
                    {'z', 0.0063}, {'0', 0.0274}, {'1', 0.0435}, {'2', 0.0312}, {'3', 0.0243},
                    {'4', 0.0194}, {'5', 0.0189}, {'6', 0.0176}, {'7', 0.0162}, {'8', 0.0166}, 
                    {'9', 0.0180}, {'!', 0.0003}, {'"', 0.00018}, {'#', 0.00854}, {'$', 0.00970}, 
                    {'%', 0.00171}, {'&', 0.00134}, {'\'', 0.00116}, {'(', 0.00043}, {')', 0.00116}, 
                    {'*', 0.02416}, {'+', 0.00232}, {',', 0.00323}, {'-', 0.01977}, {'.', 0.03167}, 
                    {'/', 0.00311}, {':', 0.00055}, {';', 0.00207}, {'<', 0.00043}, {'=', 0.00140},
                    {'>', 0.00018}, {'?', 0.00207}, {'@', 0.02386}, {'[', 0.00110}, {']', 0.00110},
                    {'^', 0.00195}, {'_', 0.01227}, {'`', 0.00116}, {'{', 0.00012}, {'|', 0.00012}, 
                    {'}', 0.00006}, {'~', 0.00153},
                    };

bool unlikelyChars(char c) { 
    return c < 'A' || (c > 'Z' && c <= 'a') || (c > 'z'); 
}

void keyXor(const char* src, char* dst, char key, int n) {
  for (int i = 0; i < n/2; ++i) { 
    dst[i] = (char)((unsigned)src[i] ^ (unsigned)key);

  }
}

char* getBuf(const char* s, int n) { 
    char* t = (char*) malloc(n);
    if (t == NULL) { 
        throw new std::out_of_range("malloc failed"); 
        }
    memset(t, 0, n);
    return t;
}

char decodeSingleCharXor(const char* src, char* dst, int n) {
    char* hexsrc = getBuf(src, 2 * n);
    //std::cout << src << "\n";     //testing
    decodeHex(src, hexsrc, (int)n);
    std::cout << "\n";
    
    double diff_squared = 0.0;
    double score = 0.0;
    char min_key = ' ';
    double min_score = (double)2147483647;

    for (char key = '0'; key <= 'z'; ++key) { 
        keyXor(hexsrc, dst, key, n);

        freq.clear();
        int total = 0;
        for (int i = 0; i < n/2; ++i) { 
            char c = tolower(dst[i]);
            freq[c] += 1;
            ++total; 
        }

        diff_squared = 0.0;
        for (const std::pair<char, double>& pr : freq) {
            char c = pr.first;
            double delta = (freq[c]/total - english_freq[c]);
            delta += (unlikelyChars(c) ? 2 : 0);
            diff_squared += delta * delta;
        }

        score = sqrt(diff_squared);
        if (score < min_score) { 
            min_key = key; 
            min_score = score; 
        }
    }
    std::cout << "Score: " << min_score << "     Key: " << min_key << "\n";
    keyXor(hexsrc, dst, min_key, n);
    std::cout << "Output: " << dst << "\n\n";
    free(hexsrc);
    return min_key;
}

//CHALLENGE 4

void print_array(const char* msg, const char* s, int n) {
  std::cout << msg << ": ";
  for (int i = 0; i < n; ++i) { std::cout << s[i]; }
  std::cout << "\n";
}

char decodeSingleCharXor2(const char* src, char* dst, int n) {
    char* hexsrc = getBuf(src, 2 * n);
    std::cout << src << "\n";
    decodeHex(src, hexsrc, (int)n);
    std::cout << hexsrc << "\n";
    
    double diff_squared = 0.0;
    double score = 0.0;
    char min_key = ' ';
    double min_score = (double)2147483647;

    for (int key = 32; key < 128; ++key) { 
        keyXor(hexsrc, dst, (char)key, n);

        freq.clear();
        int total = 0;
        for (int i = 0; i < n/2; ++i) { 
            char c = tolower(dst[i]);
            freq[c] += 1;
            ++total; 
        }

        diff_squared = 0.0;
        for (const std::pair<char, double>& pr : freq) {
            char c = pr.first;
            double delta = (freq[c]/total - english_freq[c]);
            delta += (unlikelyChars(c) ? 2 : 0);
            diff_squared += delta * delta;
        }

        score = sqrt(diff_squared);
        if (score < min_score) { 
            min_key = (char)key; 
            min_score = score; 
        }
    }
    std::cout << "Score: " << min_score << "     Key: " << min_key << "\n";
    keyXor(hexsrc, dst, min_key, n);
    std::cout << "Xor'd String: " << dst << "\n\n";
    free(hexsrc);
    return min_key;
}


//CHALLENGE 5
void repeatKeyXor(const char* src, char* dst, char* key, int n) {
    int keyend = strlen(key)-1;
    int keycount = 0;
    for (int i = 0; i < n/2; ++i) { 
        dst[i] = (char)((unsigned)src[i] ^ (unsigned)key[keycount]);
        // std::cout << "Current Key: " << key[keycount] << "\n";       //testing
        if(keycount == keyend){
            keycount = -1;
        }
        keycount++;
        //testing
        // for(int i = 0; i < strlen(dst); i++){
        //     std::cout << dst[i];
        // }
        // std::cout << "\n";
    }
}

#endif