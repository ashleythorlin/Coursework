#ifndef Challenges_h
#define Challenges_h

#include <stdio.h>
#include <iostream>
#include <string>
#include <cstring>
#include <vector>
#include <fstream>
#include <map>
#include <sstream>
#include <tuple>
#include <list>

#include "util.h"

int challenge1() {
    std::cout << "\n - - - CHALLENGE 1 - - -\n\n";

    char hexbuf[] = "49276d206b696c6c696e6720796f757220627261696e206c696b65206120706f69736f6e6f7573206d757368726f6f6d";
    char decbuf[BUFSIZ];
    char base64buf[BUFSIZ];

    memset(decbuf, 0, sizeof(decbuf));
    memset(base64buf, 0, sizeof(base64buf));
    int n = strlen(hexbuf);

    decodeHex(hexbuf, decbuf, n);
    //std::cout << decbuf << "\n";      //testing
    convertToBase64(decbuf, base64buf, strlen(decbuf));

    std::cout << "\nIn Base64: " << base64buf << "\n\n";

    return 0;
}

int challenge2(){
    std::cout << "\n - - - CHALLENGE 2 - - -\n\n";

    char source1[] = "1c0111001f010100061a024b53535009181c";
    char source2[] = "686974207468652062756c6c277320657965";

    char hex1[BUFSIZ];
    char hex2[BUFSIZ];

    memset(hex1, 0, sizeof(hex1));
    memset(hex2, 0, sizeof(hex2));

    decodeHex(source1, hex1, strnlen(source1, BUFSIZ));
    decodeHex(source2, hex2, strnlen(source2, BUFSIZ));

    char result[BUFSIZ];
    memset(result, 0, sizeof(result));

    char xordest[BUFSIZ];
    memset(xordest, 0, sizeof(xordest));
    
    int n = strnlen(source1, BUFSIZ);
    blockXor(hex1, hex2, xordest, n);

    int mask =15;   //01110100
    for(int i = 0; i < n/2; i++) {
        result[2 * i] = hexChar((xordest[i] >> 4) & mask); //converts to hex
        result[2 * i + 1] = hexChar(xordest[i] & mask);
    }

    std::cout << "\nAfter Block Xor: ";
    std::cout << result << "\n\n";

    return 0;

}

int challenge3() {
    std::cout << "\n - - - CHALLENGE 3 - - -\n\n";

    char source[] = "1b37373331363f78151b7f2b783431333d78397828372d363c78373e783a393b3736";
    
    char dest[BUFSIZ];
    memset(dest, 0, sizeof(dest));

    decodeSingleCharXor(source, dest, strlen(source));
    
    return 0;
}

//couldn't manage to get correct xor'd string, so I couldn't score lines accurately.
int challenge4() {
    std::cout << "\n - - - CHALLENGE 4 - - -\n\n";

    std::ifstream infile("chal4.txt");
    std::string line;
    char source[BUFSIZ];
    memset(source, 0, sizeof(source));

    char dest[BUFSIZ];
    memset(dest, 0, sizeof(dest));
    int linecount = 1;

    while (std::getline(infile, line)){
        std::istringstream iss(line);
        std::cout << linecount<< ". "; 
        strcpy(source, line.c_str());
        //std::cout << source << "\n";
        decodeSingleCharXor2(source, dest, strlen(source));

        //std::cout << "Xor'd String: " << dest << "\n\n";      //testing
        linecount++;
    }
    return 0;
}

int challenge5(){
    std::cout << "\n - - - CHALLENGE 5 - - -\n\n";

    char source[] = "Burning 'em, if you ain't quick and nimble I go crazy when I hear a cymbal";
    char key[] = "ICE";

    std::cout << "Source: " << source << "\n";
    std::cout << "Key: " << key << "\n";

    char hex[BUFSIZ];
    memset(hex, 0, sizeof(hex));

    char dest[BUFSIZ];
    memset(dest, 0, sizeof(dest));

    char result[BUFSIZ];
    memset(result, 0, sizeof(result));

    repeatKeyXor(source, dest, key, strlen(source));

    std::stringstream ss;
    for (int i = 0; i < strlen(dest); ++i) {
        ss << std::hex << (int)dest[i];
    }

    std::cout << "\nAfter Repeating Xor: " << ss.str() << "\n\n";

    return 0;
}


#endif